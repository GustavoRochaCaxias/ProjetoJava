package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import br.com.fiap.beans.Cliente;
import br.com.fiap.conexao.ConexaoFactory;

public class ClienteDao {
    public Connection minhaConexao;
     
    public ClienteDao() {
    	super();
    	try {
			this.minhaConexao = new ConexaoFactory().conexao();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("A conexão falhou, talvez seja melhor olhar em (ClienteDao) ");;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("A conexão falhou, talvez seja melhor olhar em (ClienteDao) ");;
		}
    }
    
    public String inserir (Cliente cliente) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				("insert into CLIENTE values (?,?,?,?,?) "); 
				stmt.setString(1, cliente.getCpf());
				stmt.setString(2,cliente.getNomecliente());
				stmt.setString(3, cliente.getEmailcliente());
				stmt.setString(4, cliente.getCargo());
				stmt.setString(5, cliente.getTelefone());
				stmt.execute();
				stmt.close();
    	return "Cliente foi cadastrado na tabela: CLIENTE";
    	
    }
    
    public String deletar(String cpf) throws SQLException {
    	PreparedStatement stmt = minhaConexao.prepareStatement
    			("Delete from CLIENTE where cpf = ?");
    	stmt.setString(1, cpf);
    	stmt.execute();
    	stmt.close();
    	return "CLIENTE deletado com sucesso";
    }

    
    public String atualizar(Cliente cliente) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("UPDATE CLIENTE SET NomeCliente = ?, EmailCliente = ?, Cargo = ?, Telefone = ? WHERE CPF = ?");
        stmt.setString(1, cliente.getNomecliente());
        stmt.setString(2, cliente.getEmailcliente());
        stmt.setString(3, cliente.getCargo());
        stmt.setString(4, cliente.getTelefone());
        stmt.setString(5, cliente.getCpf());
        stmt.executeUpdate();
        stmt.close();   
        return "Atualizado com Sucesso!";
    }
   
    public List<Cliente> selecionar() throws SQLException{
		List<Cliente> listaCliente = new ArrayList<Cliente>();
		PreparedStatement stmt = minhaConexao.prepareStatement
				("SELECT * FROM CLIENTE");
		
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				Cliente cliente = new Cliente();
				cliente.setCpf(rs.getString(1));
				cliente.setCargo(rs.getString(2));
				cliente.setEmailcliente(rs.getString(3));
				cliente.setNomecliente(rs.getString(4));
				cliente.setTelefone(rs.getString(5));
				listaCliente.add(cliente);
			}		
		return listaCliente;		
	}
}
