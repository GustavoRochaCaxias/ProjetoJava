package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;


import br.com.fiap.beans.Empresa;
import br.com.fiap.dao.EmpresaDao;

public class CadastrarEmpresa {

	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}
	static int inteiro (String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	static double real (String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}
	

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		EmpresaDao dao = new EmpresaDao();
		
		Empresa objEmpresa = new Empresa ();
		
		objEmpresa.setCnpj(inteiro("Digite o CNPJ da EMPRESA"));
		objEmpresa.setNomeempresa(texto("Digite o NOME da EMPRESA"));
		objEmpresa.setQuantfunci(texto("Digite o QUANTIDADE DE FUNCIONARIOS da EMPRESA"));
		objEmpresa.setTelefoneempresa(texto("Digite o TELFONE da EMPRESA"));

		
		System.out.println(dao.inserir(objEmpresa));

}
}