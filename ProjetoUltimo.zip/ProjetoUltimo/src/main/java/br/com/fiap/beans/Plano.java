package br.com.fiap.beans;

public class Plano {
	private String codigo;
	private String nomeplano;
	private double valor;
	private double tempo;
	public Plano() {
		super();
	}
	public Plano(String codigo, String nomeplano, double valor, double tempo) {
		super();
		this.codigo = codigo;
		this.nomeplano = nomeplano;
		this.valor = valor;
		this.tempo = tempo;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getNomeplano() {
		return nomeplano;
	}
	public void setNomeplano(String nomeplano) {
		this.nomeplano = nomeplano;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public double getTempo() {
		return tempo;
	}
	public void setTempo(double tempo) {
		this.tempo = tempo;
	}

}
