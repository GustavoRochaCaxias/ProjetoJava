package br.com.fiap.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Empresa;
import br.com.fiap.dao.EmpresaDao;

public class SelecionarEmpresa {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//Instanciar objetos 
		EmpresaDao dao = new EmpresaDao();
		
		List<Empresa> listaEmpresa = (ArrayList<Empresa>) dao.selecionar();
		
		if(listaEmpresa != null) {
			// foreach 
			for( Empresa empresa : listaEmpresa) {
				System.out.println( "CNJ:" +empresa.getCnpj() + " /EMPRESA: " + 
									empresa.getNomeempresa() + " /QUANTIDADE DE FUNCIONARIOS: " + 
						        	empresa.getQuantfunci() + " /TELEFONE: " + 
									empresa.getTelefoneempresa());
			}
		}

	}

}
