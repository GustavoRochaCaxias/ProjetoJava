package br.com.fiap.beans;

public class Empresa {
	private String nomeempresa;
	private int cnpj;
	private String quantfunci;
	private String telefoneempresa;

	public Empresa() {
		super();
	}

	public Empresa(String nomeempresa, int cnpj, String quantfunci, String telefoneempresa) {
		super();
		this.nomeempresa = nomeempresa;
		this.cnpj = cnpj;
		this.quantfunci = quantfunci;
		this.telefoneempresa = telefoneempresa;
	}

	public String getNomeempresa() {
		return nomeempresa;
	}

	public void setNomeempresa(String nomeempresa) {
		this.nomeempresa = nomeempresa;
	}

	public int getCnpj() {
		return cnpj;
	}

	public void setCnpj(int cnpj) {
		this.cnpj = cnpj;
	}

	public String getQuantfunci() {
		return quantfunci;
	}

	public void setQuantfunci(String quantfunci) {
		this.quantfunci = quantfunci;
	}

	public String getTelefoneempresa() {
		return telefoneempresa;
	}

	public void setTelefoneempresa(String telefoneempresa) {
		this.telefoneempresa = telefoneempresa;
	}
}
