package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Login;
import br.com.fiap.dao.LoginDao;

public class CadastrarLogin {
	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}
	static int inteiro (String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	static double real (String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
			LoginDao dao = new LoginDao();
			
			Login objLogin = new Login();
			
			objLogin.setCpf(texto("Digite o cpf"));
			objLogin.setEmail(texto("Digite o email"));
			objLogin.setCnpj(inteiro("Digite o cnpj"));
			objLogin.setSenha(inteiro("Digite a senha"));
			
			
			System.out.println(dao.inserir(objLogin));

	}

}
