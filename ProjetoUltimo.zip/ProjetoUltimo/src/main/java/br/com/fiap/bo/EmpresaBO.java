package br.com.fiap.bo;

import java.sql.SQLException;
import java.util.ArrayList;
import br.com.fiap.beans.Empresa;
import br.com.fiap.dao.EmpresaDao;

public class EmpresaBO {
   EmpresaDao EmpresaDao;		
	
	
	// Selecionar
	public ArrayList<Empresa> secionarBo() throws SQLException, ClassNotFoundException{
		EmpresaDao = new EmpresaDao();
		return  (ArrayList<Empresa>) EmpresaDao.selecionar();
	}
	
	public void inserirBo(Empresa empresa) throws ClassNotFoundException, SQLException  {
		EmpresaDao = new EmpresaDao();
		EmpresaDao.inserir(empresa);
	}
	
	public void atualizarBo(Empresa empresa) throws ClassNotFoundException, SQLException  {
		EmpresaDao = new EmpresaDao();
		EmpresaDao.atualizar(empresa);
	}
	
	public void deletarBo(int cnpj) throws ClassNotFoundException, SQLException {
		EmpresaDao = new EmpresaDao();
		EmpresaDao.deletar(cnpj);
	}	


}
