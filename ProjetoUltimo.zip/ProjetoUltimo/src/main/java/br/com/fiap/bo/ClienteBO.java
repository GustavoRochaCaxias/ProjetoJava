package br.com.fiap.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.beans.Cliente;
import br.com.fiap.dao.ClienteDao;

public class ClienteBO {
	
	ClienteDao ClienteDao;		
	
	
	// Selecionar
	public ArrayList<Cliente> secionarBo() throws SQLException, ClassNotFoundException{
		ClienteDao = new ClienteDao();
		return  (ArrayList<Cliente>) ClienteDao.selecionar();
	}
	
	public void inserirBo(Cliente cliente) throws ClassNotFoundException, SQLException  {
		ClienteDao = new ClienteDao();
		ClienteDao.inserir(cliente);
	}
	
	public void atualizarBo(Cliente cliente) throws ClassNotFoundException, SQLException  {
		ClienteDao = new ClienteDao();
		ClienteDao.atualizar(cliente);
	}
	
	public void deletarBo(String cpf) throws ClassNotFoundException, SQLException {
		ClienteDao = new ClienteDao();
		ClienteDao.deletar(cpf);
	}	

}

