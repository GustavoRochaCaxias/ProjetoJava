package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.fiap.beans.Endereco;
import br.com.fiap.conexao.ConexaoFactory;

public class EnderecoDao {
   public Connection enderecoConexao;
   
   public EnderecoDao () throws ClassNotFoundException, SQLException {
	   super();
	   this.enderecoConexao = new ConexaoFactory(). conexao();
   }
   
   public String inserir (Endereco endereco) throws SQLException {
	   PreparedStatement stmt = enderecoConexao.prepareStatement
			   ("insert into ENDERECO values (?,?,?,?,?,?,?)");
	   			stmt.setInt(1,endereco.getCep() );
	   			stmt.setInt(2,endereco.getLougradouro() );
	   			stmt.setInt(3, endereco.getNumero());
	   			stmt.setString(4,endereco.getBairro() );
	   			stmt.setString(5, endereco.getCidade());
	   			stmt.setString(6, endereco.getPais());
	   			stmt.setString(7, endereco.getEstado());
	   			stmt.execute();
	   			stmt.close();
	return "Endereço foi cadastrado na tabela: ENDERECO"; 
   }


	}


