package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Plano;
import br.com.fiap.dao.PlanoDao;

public class CadastroPlano {

	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}
	static int inteiro (String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	static double real (String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		PlanoDao dao = new PlanoDao();
		
		Plano objPlano = new Plano();
		
		objPlano.setCodigo(texto("Digite o codigo"));
		objPlano.setNomeplano(texto("Digite o nome do plano"));
		objPlano.setValor(real("Digite o valor"));
		objPlano.setTempo(real("Digite o tempo de plano"));
		
		System.out.println(dao.inserir(objPlano));
		
		
	}

}
