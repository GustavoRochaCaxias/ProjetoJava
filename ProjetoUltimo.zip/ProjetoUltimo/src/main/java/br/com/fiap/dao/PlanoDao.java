package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.fiap.beans.Plano;
import br.com.fiap.conexao.ConexaoFactory;

public class PlanoDao {

	public Connection planoConexao;
	
	public PlanoDao () throws ClassNotFoundException, SQLException {
		super();
		this.planoConexao = new ConexaoFactory().conexao();
		
	}
	
	public String inserir (Plano plano) throws SQLException {
		PreparedStatement stmt = planoConexao.prepareStatement
				("insert into PLANO values (?,?,?,?)");
				stmt.setString(1, plano.getCodigo());
				stmt.setString(2, plano.getNomeplano());
				stmt.setDouble(3, plano.getValor());
				stmt.setDouble(4, plano.getTempo());
				stmt.execute();
				stmt.close();
		return "Plano foi adicionado na tabela:PLANO";
		
		
	}
}
