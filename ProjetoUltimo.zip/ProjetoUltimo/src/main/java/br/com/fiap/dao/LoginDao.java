package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.fiap.beans.Login;
import br.com.fiap.conexao.ConexaoFactory;

public class LoginDao {

   public Connection loginConexao;
   public LoginDao() throws ClassNotFoundException, SQLException {
	   super();
	   this.loginConexao = new ConexaoFactory() .conexao();
   }
	   public String inserir (Login login) throws SQLException {
		   PreparedStatement stmt = loginConexao.prepareStatement
				   ("insert into LOGIN values (?,?,?,?)");
		   			stmt.setString(1, login.getCpf());
		   			stmt.setString(2, login.getEmail());
		   			stmt.setInt(3, login.getCnpj());;
		   			stmt.setInt(4, login.getSenha());
		   			stmt.execute();
		   			stmt.close();
		   
		   return "login inserido na tabela: LOGIN ";
		   
	   }
	   
   


}
