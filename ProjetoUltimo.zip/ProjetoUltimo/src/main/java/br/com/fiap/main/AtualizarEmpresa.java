package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Empresa;
import br.com.fiap.dao.EmpresaDao;

public class AtualizarEmpresa {
	
	static int inteiro (String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// Instanciar objetos
		Empresa objEmpresa = new Empresa();
		
		EmpresaDao dao = new EmpresaDao();
		
		objEmpresa.setCnpj(inteiro("Insira o CNPJ a ser alterado"));
		objEmpresa.setNomeempresa(texto("Nome"));
		objEmpresa.setQuantfunci(texto("Quantidade de funcionarios"));
		objEmpresa.setTelefoneempresa(texto("Telefone"));
		
		System.out.println(dao.atualizar(objEmpresa));

}
}
