package br.com.fiap.beans;

public class Cliente {
		private String cpf;
		private String nomecliente;
		private String emailcliente;
		private String cargo;
		private String telefone;
		
		public Cliente() {
			super();
		}

		public Cliente(String cpf, String nomecliente, String emailcliente, String cargo, String telefone) {
			super();
			this.cpf = cpf;
			this.nomecliente = nomecliente;
			this.emailcliente = emailcliente;
			this.cargo = cargo;
			this.telefone = telefone;
		}

		public String getCpf() {
			return cpf;
		}

		public void setCpf(String cpf) {
			this.cpf = cpf;
		}

		public String getNomecliente() {
			return nomecliente;
		}

		public void setNomecliente(String nomecliente) {
			this.nomecliente = nomecliente;
		}

		public String getEmailcliente() {
			return emailcliente;
		}

		public void setEmailcliente(String emailcliente) {
			this.emailcliente = emailcliente;
		}

		public String getCargo() {
			return cargo;
		}

		public void setCargo(String cargo) {
			this.cargo = cargo;
		}

		public String getTelefone() {
			return telefone;
		}

		public void setTelefone (String telefone) {
			this.telefone = telefone;
		}
		
}

