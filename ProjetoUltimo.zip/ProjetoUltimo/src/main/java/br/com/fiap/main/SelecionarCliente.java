package br.com.fiap.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import br.com.fiap.beans.Cliente;

import br.com.fiap.dao.ClienteDao;

public class SelecionarCliente {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//Instanciar objetos 
		ClienteDao dao = new ClienteDao();
		
		List<Cliente> listaCliente = (ArrayList<Cliente>) dao.selecionar();
		
		if(listaCliente != null) {
			// foreach 
			for( Cliente cliente : listaCliente) {
				System.out.println(cliente.getCpf() + " " + 
									cliente.getCargo() + " " + 
						        	cliente.getEmailcliente() + " " + 
									cliente.getNomecliente() + " " +
						        	cliente.getTelefone()+ "");
			}
		}

	}
}
