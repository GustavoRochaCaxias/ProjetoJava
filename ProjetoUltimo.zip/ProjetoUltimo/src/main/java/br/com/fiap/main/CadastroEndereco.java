package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Endereco;
import br.com.fiap.dao.EnderecoDao;

public class CadastroEndereco {
	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}
	static int inteiro (String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	static double real (String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		EnderecoDao  dao = new EnderecoDao();
		
		Endereco objEndereco = new Endereco();

		objEndereco.setCep(inteiro("Digite o Cep"));
		objEndereco.setLougradouro(inteiro("Digite o Lougradouro"));
		objEndereco.setNumero(inteiro("Digite o numero "));
		objEndereco.setBairro(texto("Digite o bairro"));
		objEndereco.setCidade(texto("Digite a cidade"));
		objEndereco.setPais(texto("Digite o pais"));
		objEndereco.setEstado(texto("Digite o estado"));
		
		System.out.println(dao.inserir(objEndereco));
	}

}
