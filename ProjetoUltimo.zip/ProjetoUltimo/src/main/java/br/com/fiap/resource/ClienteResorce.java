package br.com.fiap.resource;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.beans.Cliente;
import br.com.fiap.bo.ClienteBO;



public class ClienteResorce {

	@Path("/cliente")
	public class AlunoResource {
		

			
		private ClienteBO clienteBO = new ClienteBO();	
		
		@GET
		@Produces(MediaType.APPLICATION_JSON)
		public ArrayList<Cliente> buscar() throws SQLException, ClassNotFoundException {
			return (ArrayList<Cliente>) clienteBO.secionarBo();
		}
		
		@POST
		@Consumes(MediaType.APPLICATION_JSON)
		public Response cadastroRs (Cliente cliente, @Context UriInfo uriInfo ) throws ClassNotFoundException, SQLException {
			clienteBO.inserirBo(cliente);
			UriBuilder builder = uriInfo.getAbsolutePathBuilder();
			builder.path(cliente.getCpf());
			return Response.created(builder.build()).build();		
		}
		
		@PUT
		@Path("/{cpf}")
		@Consumes(MediaType.APPLICATION_JSON)
		public Response atualizaRs (Cliente cliente, @PathParam("cpf") String cpf) throws SQLException, ClassNotFoundException {
			clienteBO.atualizarBo(cliente);
			return Response.ok().build();
		}
		
		@DELETE
		@Path("/{cpf}")
		@Consumes(MediaType.APPLICATION_JSON)
		public Response deleteRs (@PathParam("cpf") String cpf) throws ClassNotFoundException, SQLException {
			clienteBO.deletarBo(cpf);
			return Response.ok().build();
		}
	}
	
}
