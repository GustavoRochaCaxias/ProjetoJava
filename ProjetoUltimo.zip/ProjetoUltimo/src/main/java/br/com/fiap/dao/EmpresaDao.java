package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Empresa;
import br.com.fiap.conexao.ConexaoFactory;

public class EmpresaDao {
	public Connection empresaConection;
    
	public EmpresaDao() throws ClassNotFoundException, SQLException {
		super();
		this.empresaConection = new ConexaoFactory().conexao();
	}
		   public String inserir (Empresa empresa) throws SQLException {
		    	PreparedStatement stmt = empresaConection.prepareStatement
		    			("insert into EMPRESA values (?,?,?,?)");
		    	        stmt.setInt(1,empresa.getCnpj());
		    			stmt.setString(2,empresa.getNomeempresa());
		    			stmt.setString(3,empresa.getQuantfunci());
		    			stmt.setString(4, empresa.getTelefoneempresa());
		    			stmt.execute();
		    			stmt.close();
				return "Empresa foi cadastrada na tabela:EMPRESA";
		   }
		   
		   public String deletar(int cnpj) throws SQLException {
		    	PreparedStatement stmt = empresaConection.prepareStatement
		    			("Delete from EMPRESA where cnpj = ?");
		    	stmt.setInt(1, cnpj);
		    	stmt.execute();
		    	stmt.close();
		    	return "EMPRESA deletado com sucesso";
		    }
		   public String atualizar(Empresa empresa) throws SQLException {
		        PreparedStatement stmt = empresaConection.prepareStatement("UPDATE EMPRESA SET NomeEmpresa = ?, Quantfunci= ?,Telefoneempresa = ? WHERE CNPJ = ?");
		        stmt.setString(1, empresa.getNomeempresa());
		        stmt.setString(2, empresa.getQuantfunci());
		        stmt.setString(3, empresa.getTelefoneempresa());
		        stmt.setInt(4,empresa.getCnpj());
		        stmt.executeUpdate();
		        stmt.close();   
		        return "Atualizado com Sucesso!";
		    }
		   public List<Empresa> selecionar() throws SQLException{
				List<Empresa> listaEmpresa = new ArrayList<Empresa>();
				PreparedStatement stmt = empresaConection.prepareStatement
						("SELECT * FROM EMPRESA");
				
					ResultSet rs = stmt.executeQuery();
					
					while(rs.next()) {
						Empresa empresa = new Empresa();
						empresa.setCnpj(rs.getInt(1));
						empresa.setNomeempresa(rs.getString(2));
						empresa.setQuantfunci(rs.getString(3));
						empresa.setTelefoneempresa(rs.getString(4));
						listaEmpresa.add(empresa);
					}		
				return listaEmpresa;		
			}
		   
 
		    	
		  
		    
	}
