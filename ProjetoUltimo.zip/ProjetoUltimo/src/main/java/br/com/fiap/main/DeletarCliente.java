package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.dao.ClienteDao;

public class DeletarCliente {

	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// Instanciar objetos 
		Cliente objCliente = new Cliente();
		
		ClienteDao dao = new ClienteDao();
		
		objCliente.setCpf(texto("Digite o cpf do CLIENTE a ser deletado"));
		
		System.out.println(dao.deletar(objCliente.getCpf()));

	}

}


