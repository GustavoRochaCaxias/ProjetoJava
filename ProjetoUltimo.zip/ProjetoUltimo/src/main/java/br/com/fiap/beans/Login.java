package br.com.fiap.beans;

public class Login {
	private String cpf;
	private String email;
	private int cnpj;
	private int senha;
	public Login() {
		super();
	}
	public Login(String cpf, String email, int cnpj, int senha) {
		super();
		this.cpf = cpf;
		this.email = email;
		this.cnpj = cnpj;
		this.senha = senha;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getCnpj() {
		return cnpj;
	}
	public void setCnpj(int cnpj) {
		this.cnpj = cnpj;
	}
	public int getSenha() {
		return senha;
	}
	public void setSenha(int senha) {
		this.senha = senha;
	}
	
}
