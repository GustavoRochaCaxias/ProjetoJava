package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.dao.ClienteDao;

public class AtualizarCliente {

	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// Instanciar objetos
		Cliente objCliente = new Cliente();
		
		ClienteDao dao = new ClienteDao();
		
		objCliente.setCpf(texto("Insira o CPF a ser alterado"));
		objCliente.setNomecliente(texto("Nome"));
		objCliente.setEmailcliente(texto("Email"));
		objCliente.setCargo(texto("Cargo"));
		objCliente.setTelefone(texto("Telefone"));
		
		System.out.println(dao.atualizar(objCliente));

}
}